const express = require('express');
const cors = require('cors');
const path = require('path');
require('dotenv').config();

const analyzeRouter = require('./routes/analyze');
const chatRouter = require('./routes/chat');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

app.use('/api/analyze', analyzeRouter);
app.use('/api/chat', chatRouter);

app.use((req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`\n🚀 Doofinder Sales Copilot running at http://localhost:${PORT}\n`);
});
